
package com.mycompany.lab20q2;


public class Lab20Q2 {

    public static void main(String[] args)
    {
        ClickCounter t=new ClickCounter();
        t.show();
    }
}
