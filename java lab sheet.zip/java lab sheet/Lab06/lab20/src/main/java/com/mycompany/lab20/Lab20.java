

package com.mycompany.lab20;

public class Lab20 {

    public static void main(String[] args)
    {
        Jframe t=new Jframe();
        t .show();
        
    }
}
