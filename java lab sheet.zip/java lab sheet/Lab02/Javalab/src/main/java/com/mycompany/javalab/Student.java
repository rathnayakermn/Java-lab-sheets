
package com.mycompany.javalab;


public class Student {
    
}
