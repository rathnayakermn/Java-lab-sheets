
package com.mycompany.javalab;


public class Javalab {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
