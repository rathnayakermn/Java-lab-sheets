
package com.mycompany.datetest;


public class DateTest {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
