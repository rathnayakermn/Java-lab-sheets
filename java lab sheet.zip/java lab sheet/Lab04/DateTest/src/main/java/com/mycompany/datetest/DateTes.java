
package com.mycompany.datetest;


public class DateTes {
    public static void main(String[]args)
    {
        Date d=new Date(6,6,2023);
        d.setDate(10);
        System.out.println("Date is " + d.getDate());
        d.displayDate();
        
    }
    
}
