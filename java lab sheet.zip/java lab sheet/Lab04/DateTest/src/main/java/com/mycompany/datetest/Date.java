
package com.mycompany.datetest;

public class Date {
    
    private int month;
    private int date;
    private int year;
    
    public Date(int month, int day,int year){
        this.month=month;
        this.date=date;
        this.year = year;
    }
     public void setDate(int d){
         date=d;
         
     }
     public int getDate(){
         return date;
     }
     // do the same code for month and year
     public void displayDate()
     {
                   
     }
    
    
}
