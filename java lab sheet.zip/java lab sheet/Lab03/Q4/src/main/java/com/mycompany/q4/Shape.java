
package com.mycompany.q4;


public class Shape {
    
}
