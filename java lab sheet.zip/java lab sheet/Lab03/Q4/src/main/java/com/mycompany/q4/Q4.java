
package com.mycompany.q4;


public class Q4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
