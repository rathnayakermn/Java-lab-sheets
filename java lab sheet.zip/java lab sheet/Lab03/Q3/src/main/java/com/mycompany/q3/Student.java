
package com.mycompany.q3;


public  class Student {
    final int marks=100;//final variables cannot be reasign
    final void display(){
        System.out.println(marks);
    }
    
    
    
}
