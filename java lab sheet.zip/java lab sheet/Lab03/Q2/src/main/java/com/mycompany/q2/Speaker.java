
package com.mycompany.q2;


public interface Speaker {
    
    void speaker();
    
    
}
