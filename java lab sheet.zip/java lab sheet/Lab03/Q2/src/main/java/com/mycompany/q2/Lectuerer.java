/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.q2;


public class Lectuerer  implements Speaker{
    
    public void speaker(){
        System.out.println();
    }
    
}
