
package com.mycompany.q2;


public class Priest implements Speaker{
    
    @Override
    public void speaker(){
        System.out.println("As priest, ");
    }
}
