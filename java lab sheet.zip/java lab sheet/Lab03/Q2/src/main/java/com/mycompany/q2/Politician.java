
package com.mycompany.q2;


public class Politician implements Speaker {
   
    @Override
    
    public void speaker(){
        System.out.println("As a politician");
        
    }

}